#include "indexGraph.h"
#include <fstream>
#define EVAL_SI
;
std::string get_FileBaseName(std::string path)
{
    std::string name;
    for (int i = path.size() - 1; i > 0; i--)
    {
        if (path[i] == '\\' || path[i] == '/')
        {
            name = path.substr(i + 1);
            return name;
        }
    }
    name = path;
    return name;
}
std::string get_GroMethod(std::string path)
{
    std::string name;
    for (int i = 0; i < path.size(); i++)
    {
        if (path[i] == '_')
        {
            name = path.substr(i + 1);
            return name;
        }
    }
    name = path;
    return name;
}
int main(int argc, char **argv)
{
    string directname = "../data/";
    string outdirect = "../hash_data/";
    string groDirect = "../gro_data/";
    string name = argv[1];
    int N = stoi(argv[2]);
    int test = stoi(argv[3]);
    int times = stoi(argv[4]);
    int M = 0;
    vec *G = new vec[N];
    // ofstream out(string("tri.log.csro0.dyn")+to_string(BINRATIO), ios::app);
    // ofstream out(string("tri.log.csro0.acc"), ios::app);
    auto &out = cout;
    utils::readGraph(directname + name + ".txt", G, N, M);
    // utils::readGraphDAG(directname + name + ".txt", G, N, M);

    Graph OG(G, N);
    double origtime = 0, rangetime = 0, indextime = 0;
    double OGT = 1;
    for (int i = 0; i < times; i++)
    {
        if (test == -1)
            break;
        OGT += OG.calTri_simd(times == 1);
        cout << "\r";
    }
    OG.reportRatio(out);
    if (test == -1)
    {
        delete[] G;
        return 0;
    }
    else if (test == 1)
    {
        name = "test_" + name;
        outdirect = "../maxnode_hash_data/";
    }
    else if (test == 8)
    {
        name = "test_" + name;
        outdirect = "../dag_hash_data/";
        string idirect = outdirect + name + "_index_nb_";
        string inode = idirect + "node.csv";
        string iid = idirect + "id.csv";
        cout << inode << endl;
        // cout << iid << endl;
        indexGraph IG(G, N, inode, iid, M);
        cout << iid << endl;
        for (int i = 0; i < times; i++)
        {
            indextime += IG.calTri_simd(times == 1);
            cout << "\r";
        }
        IG.reportRatio(out);
        out << "\n>" << name << "<\n"
            << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << endl;
        out << OGT / times << "\t" << indextime / times << endl;
        out << OGT / indextime << endl;
        out << ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << endl;
        delete[] G;
        return 0;
    }
    if (test != 6)
    {
        string idirect = outdirect + name + "_index_nb_";
        string inode = idirect + "node.csv";
        string iid = idirect + "id.csv";
        cout << inode << endl;
        // cout << iid << endl;
        indexGraph IG(G, N, inode, iid, M);
        cout << iid << endl;
        for (int i = 0; i < times; i++)
        {
#ifdef EVAL_SI
            indextime += IG.calTri_simd(times == 1);
#else
            indextime += IG.calTri_norepeat(times == 1);
#endif
            cout << "\r";
        }
        IG.reportRatio(out);
        // cout << "IG Rate: " << OGT / IGT << endl;
        // cout << "Index Time: " << IGT << endl;
    }
    else
    {
        indextime = 1;
    }

    out << "\n>" << name << "<\n"
        << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << endl;
    out << OGT / times << "\t" << origtime / times << "\t" << rangetime / times << "\t" << indextime / times << endl;
    out << OGT / origtime << "\t" << OGT / rangetime << "\t" << OGT / indextime << endl;
    out << ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << endl;
    delete[] G;
}
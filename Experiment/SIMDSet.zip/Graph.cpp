#include "Graph.h"
#include <immintrin.h>
// #include <avxintrin.h>
void Graph::commonNeighbor(const int i, const int j, unsigned long &cn)
{
    utils::commonNeighbor(G[i], G[j], cn, 0, degrees[i], 0, degrees[j]);
}

unsigned long long orgcmpr = 0;
extern chrono::duration<double> mergetime;
void Graph::reportRatio(ostream &out = cout)
{

    // cout<<"Reduced ratio:"<<(float)mins/maxs<<endl<<flush;
    // cout<<"Reduced ratio(AVG):"<<avgs/times<<endl<<flush;
    // if (orgcmpr)
    //     cout << "Reduced ratio(Actual):" << (float)actcmpr / orgcmpr << endl
    //          << flush;
    // cout<<"Binary Search Time:"<<bintime.count()<<endl<<flush;
    // cout << "Merge Time:" << mergetime.count() << endl
    //      << flush;
    out << "Orig Merge Time:" << mergetime.count() << endl
        << flush;
    // mins = 0;
    // maxs = 0;
    // avgs = 0;
    // times = 0;
    // actcmpr = 0;
    mergetime = chrono::duration<double>(0);
    // bintime = chrono::duration<double>(0);
}
void Graph::commonNeighborNB(const int i, const int j, unsigned long &cn)
{

    int id1 = 0, id2 = 0, ed1 = degrees[i], ed2 = degrees[j];
    vec &vec1 = G[i];
    vec &vec2 = G[j];
#ifdef TIMECOUNT
    std::chrono::_V2::system_clock::time_point merge_start_time;
    merge_start_time = std::chrono::high_resolution_clock::now();
#endif
    while (id1 != ed1 && id2 != ed2)
    {
        if (vec1[id1] == vec2[id2])
        {
            // if(vec1[id1]>j)
            cn++;
            // (*orgcmpr)--;
            id1++;
            id2++;
        }
        else if (vec1[id1] < vec2[id2])
            id1++;
        else
            id2++;
    }
#ifdef TIMECOUNT
    mergetime += std::chrono::high_resolution_clock::now() - merge_start_time;
#endif
}
#include <immintrin.h>

static void dump(__m256i v)
{
    int item;
    item = _mm256_extract_epi32(v, 0);
    cout << item << endl;
    item = _mm256_extract_epi32(v, 1);
    cout << item << endl;
    item = _mm256_extract_epi32(v, 2);
    cout << item << endl;
    item = _mm256_extract_epi32(v, 3);
    cout << item << endl;
    item = _mm256_extract_epi32(v, 4);
    cout << item << endl;
    item = _mm256_extract_epi32(v, 5);
    cout << item << endl;
    item = _mm256_extract_epi32(v, 6);
    cout << item << endl;
    item = _mm256_extract_epi32(v, 7);
    cout << item << endl;
}

static __m256i shuffle_mask32[256];

static int getBit(int value, int position)
{
    return ((value & (1 << position)) >> position);
}

void prepare_shuffling_dict32()
{
    for (int i = 0; i < 256; i++)
    {
        int counter = 0;
        char permutation[32];
        memset(permutation, 0xFF, sizeof(permutation));
        for (char b = 0; b < 8; b++)
        {
            if (getBit(i, b))
            {
                // permutation[counter++] = 4*b;
                // permutation[counter++] = 4*b + 1;
                // permutation[counter++] = 4*b + 2;
                // permutation[counter++] = 4*b + 3;

                permutation[counter++] = b & 0xff;
                permutation[counter++] = (b >> 8) & 0xff;
                permutation[counter++] = (b >> 16) & 0xff;
                permutation[counter++] = (b >> 24) & 0xff;
            }
        }
        __m256i mask = _mm256_loadu_si256((const __m256i *)permutation);
        shuffle_mask32[i] = mask;
    }
}

size_t highlyscalable_avx2_intersection(const uint32_t *A, const size_t s_a,
                                        const uint32_t *B, const size_t s_b)
{
    //   assert(out != A);
    //   assert(out != B);
    //   const uint32_t *const initout(out);
    size_t out = 0;
    size_t i_a = 0, i_b = 0;

    // trim lengths to be a multiple of 8
    size_t st_a = (s_a / 8) * 8;
    size_t st_b = (s_b / 8) * 8;

    while (i_a < st_a && i_b < st_b)
    {
        //[ load segments of four 32-bit elements
        __m256i v_a = _mm256_loadu_si256((__m256i *)&A[i_a]);
        __m256i v_b = _mm256_loadu_si256((__m256i *)&B[i_b]);
        //]

        //[ move pointers
        const uint32_t a_max = A[i_a + 7];
        const uint32_t b_max = B[i_b + 7];
        i_a += (a_max <= b_max) * 8;
        i_b += (a_max >= b_max) * 8;
        //]

        //[ compute mask of common elements
        const __m256i rotate_arg = _mm256_set_epi32(0, 7, 6, 5, 4, 3, 2, 1);
        __m256i cmp_mask = _mm256_cmpeq_epi32(v_a, v_b); // pairwise comparison

        for (int i = 0; i < 7; i++)
        {
            v_b = _mm256_permutevar8x32_epi32(v_b, rotate_arg); // shuffling
            __m256i cmp_mask1 = _mm256_cmpeq_epi32(v_a, v_b);   // again...
            cmp_mask = _mm256_or_si256(cmp_mask, cmp_mask1);
        }

        // convert the 256-bit mask to the 8-bit mask
        const int mask = _mm256_movemask_ps(_mm256_castsi256_ps(cmp_mask));
        // cout<<"mask: "<<mask<<endl;

        //[ copy out common elements
        // const __m256i p = _mm256_permutevar8x32_epi32(v_a, shuffle_mask32[mask]);
        // _mm256_storeu_si256((__m256i *)out, p);
        out += _mm_popcnt_u32(mask); // a number of elements is a weight of the mask
                                     //]
    }

    // intersect the tail using scalar intersection
    while (i_a < s_a && i_b < s_b)
    {
        if (A[i_a] < B[i_b])
        {
            i_a++;
        }
        else if (B[i_b] < A[i_a])
        {
            i_b++;
        }
        else
        {
            out++;
            i_a++;
            i_b++;
        }
    }

    return out;
}
void Graph::commonNeighborNB_simd(const int i, const int j, unsigned long &cn)
{
    int id1 = 0, id2 = 0, ed1 = degrees[i], ed2 = degrees[j];
    vec &vec1 = G[i];
    vec &vec2 = G[j];
    cn += highlyscalable_avx2_intersection((uint32_t*)vec1.data(), vec1.size(),(uint32_t*)vec2.data(), vec2.size());
}
void Graph::commonNeighborCP(const int i, const int j, unsigned long &cn)
{
    vec &vec1 = G[i];
    vec &vec2 = G[j];
    int id1 = 0;
    int ed1 = degrees[i];
    int id2 = 0;
    int ed2 = degrees[j];
    while (id1 != ed1 && id2 != ed2)
    {
        if (vec1[id1] == vec2[id2])
        {
            id1++;
            id2++;
        }
        else if (vec1[id1] < vec2[id2])
            id1++;
        else
            id2++;
        cn++;
    }
}

void Graph::commonNeighborBS(const int i, const int j, unsigned long &cn)
{
    int d1 = degrees[i];
    int d2 = degrees[j];
    if (d1 < d2)
        utils::commonNeighborBS(G[i], G[j], cn, 0, d1, 0, d2);
    else
        utils::commonNeighborBS(G[j], G[i], cn, 0, d2, 0, d1);
}

double Graph::calCN(const pvec &nodePairs, const bool NB)
{
    auto start_time = chrono::high_resolution_clock::now();
    unsigned long result = 0;
    for (const pair<int, int> &p : nodePairs)
    {
        commonNeighbor(p.first, p.second, result);
    }
    auto end_time = chrono::high_resolution_clock::now();
    cout << endl
         << "Total CNs:" << result << endl;
    chrono::duration<double> diff = end_time - start_time;
    return diff.count();
}

double Graph::calCNBS(const pvec &nodePairs)
{
    auto start_time = chrono::high_resolution_clock::now();
    unsigned long result = 0;
    for (const pair<int, int> &p : nodePairs)
        commonNeighborBS(p.first, p.second, result);
    auto end_time = chrono::high_resolution_clock::now();
    cout << endl
         << "Total CNs:" << result << endl;
    chrono::duration<double> diff = end_time - start_time;
    return diff.count();
}

unsigned long Graph::calCNCP(const pvec &nodePairs)
{
    unsigned long result = 0;
    for (const pair<int, int> &p : nodePairs)
        commonNeighborCP(p.first, p.second, result);
    return result;
}

void Graph::calCN(const vec &nodes)
{
    auto start_time = chrono::high_resolution_clock::now();
    unsigned long result = 0;
    int s = nodes.size();
    for (int m = 0; m != s - 1; m++)
    {
        int i = nodes[m];
        for (int j = m + 1; j != s; j++)
        {
            int n = nodes[j];
            commonNeighbor(i, n, result);
        }
    }
    cout << endl
         << "Total CNs:" << result << endl;
    auto end_time = chrono::high_resolution_clock::now();
    chrono::duration<double> diff = end_time - start_time;
    cout << diff.count() * 1000 << " ms " << endl;
}
double Graph::calTri_simd(bool reportNumber)
{
    tqdm bar;
    auto start_time = chrono::high_resolution_clock::now();
    unsigned long result = 0;
    for (int i = 0; i != N; i++)
    {

        vec &adj = G[i];
        int s = adj.size();
        for (int j = 0; j != s; j++)
        {
            int n = adj[j];
            // if(n>i)
            commonNeighborNB_simd(i, n, result);
        }
        bar.progress(i + 1, N);
    }
    auto end_time = chrono::high_resolution_clock::now();
    if (reportNumber)
        cout << endl
             << "Total Triangles:" << result << endl;
    chrono::duration<double> diff = end_time - start_time;
    return diff.count();
}
double Graph::calTri(bool reportNumber)
{
    tqdm bar;
    auto start_time = chrono::high_resolution_clock::now();
    unsigned long result = 0;
    for (int i = 0; i != N; i++)
    {

        vec &adj = G[i];
        int s = adj.size();
        for (int j = 0; j != s; j++)
        {
            int n = adj[j];
            // if(n>i)
            commonNeighborNB(i, n, result);
        }
        bar.progress(i + 1, N);
    }
    auto end_time = chrono::high_resolution_clock::now();
    if (reportNumber)
        cout << endl
             << "Total Triangles:" << result << endl;
    chrono::duration<double> diff = end_time - start_time;
    return diff.count();
}

double Graph::calF(const pvec &nodePairs, const bool NB)
{
    tqdm bar;
    long double CNDP = 0.0, CNDP2 = 0.0;
    int marked = 0;
    int psize = nodePairs.size();
    for (const pair<int, int> &p : nodePairs)
    {
        int i = p.first;
        int n = p.second;
        unsigned long CN = 0;
        if (NB)
            commonNeighborNB(i, n, CN);
        else
            commonNeighbor(i, n, CN);
        CNDP = CNDP + (double)(2 * CN + 1);
        CNDP2 += (degrees[i] + degrees[n] + 1);
        bar.progress(++marked, psize);
    }
    CNDP = CNDP / CNDP2;
    return CNDP;
}

double Graph::calR(const pvec &nodePairs)
{
    tqdm bar;
    long double R = 0.0;
    int marked = 0;
    int psize = nodePairs.size();
    for (const pair<int, int> &p : nodePairs)
    {
        int i = p.first;
        int n = p.second;
        R += degrees[i] < degrees[n] ? (double)degrees[i] / degrees[n] : (double)degrees[n] / degrees[i];
        bar.progress(++marked, psize);
    }
    R /= psize;
    return R;
}

void Graph::calF()
{
    long double CND = 0.0;
    long double CNDP = 0.0;
    unsigned long total = 0;
    tqdm bar;
    int marked = 0;
    for (int i = 0; i < N - 1; i++)
    {
        int len = N - i - 1;
        int *CN = new int[len];
        fill_n(CN, len, 0);
        int d = degrees[i];
        for (const int &adj : G[i])
        {
            for (const int &adj2 : G[adj])
            {
                if (adj2 > i)
                    CN[adj2 - i - 1] = CN[adj2 - i - 1] + 1;
            }
        }
        for (int j = 0; j < len; j++)
        {
            int CP = d + degrees[j + i + 1];
            CNDP = CNDP + (double)(2 * CN[j] + 1) / (CP + 1);
            if (CN[j] != 0)
            {
                CND = CND + (double)(2 * CN[j]) / CP;
                total++;
            }
        }
        delete[] CN;
        marked++;
        bar.progress(marked, N);
    }
    CND = CND / total;
    CNDP = (2 * CNDP) / N / (N - 1);
    cout << endl
         << "NF2: " << CND << endl;
    cout << "NPF2: " << CNDP << endl;
}

void Graph::calTriF()
{
    tqdm bar;
    long double CND = 0.0;
    long double CNDP = 0.0;
    unsigned long total = 0;
    unsigned long edges = 0;
    int marked = 0;
    for (int i = 0; i != N; i++)
    {
        for (const int &n : G[i])
        {
            unsigned long CN;
            commonNeighbor(i, n, CN);
            if (CN != 0)
            {
                CND = CND + (double)(2 * CN) / (degrees[i] + degrees[n]);
                total++;
            }
            CNDP = CNDP + (double)(2 * CN + 1) / (degrees[i] + degrees[n] + 1);
            edges++;
        }
        bar.progress(++marked, N);
    }
    cout << endl
         << "Edges:" << edges << ", Total:" << total << endl;
    CND = CND / total;
    CNDP = CNDP / edges;
    cout << "TriNF2: " << CND << endl;
    cout << "TriDF2: " << CNDP << endl;
}

int Graph::selectPivot(const vec &P, const vec &X)
{
    int p = P[0];
    int si = 0;
    int ps = P.size();

    for (const int &v : P)
    {
        unsigned long cn = 0;
#ifdef TIMECOUNT
        std::chrono::_V2::system_clock::time_point merge_start_time;
        merge_start_time = std::chrono::high_resolution_clock::now();
#endif
        utils::commonNeighbor(G[v], P, cn, 0, degrees[v], 0, ps);
#ifdef TIMECOUNT
        mergetime += std::chrono::high_resolution_clock::now() - merge_start_time;
#endif
        if (cn > si)
        {
            si = cn;
            p = v;
        }
    }

    for (const auto &v : X)
    {
        unsigned long cn = 0;
#ifdef TIMECOUNT
        std::chrono::_V2::system_clock::time_point merge_start_time;
        merge_start_time = std::chrono::high_resolution_clock::now();
#endif
        utils::commonNeighbor(G[v], P, cn, 0, degrees[v], 0, ps);
#ifdef TIMECOUNT
        mergetime += std::chrono::high_resolution_clock::now() - merge_start_time;
#endif
        if (cn > si)
        {
            si = cn;
            p = v;
        }
    }
    return p; // 返回P和X中的节点的邻居与 P交集最多的节点。
}

void Graph::BKP(vec &P, vec &X, unsigned long &result)
{

    if (P.empty())
    {
        if (X.empty())
            result++;
        return;
    }

    int u = selectPivot(P, X);
    int vit1 = 0;
    int vit2 = 0;
    int ud = G[u].size();
    int ps = P.size();
    int xs = X.size();

    while (vit1 != ps)
    {
        if (vit2 == ud || P[vit1] < G[u][vit2])
        {
            int v = P[vit1];
            int gvs = G[v].size();
            vec NP;
            NP.reserve(min(ps, gvs));
            vec NX;
            NX.reserve(min(xs, gvs));
#ifdef TIMECOUNT
            std::chrono::_V2::system_clock::time_point merge_start_time;
            merge_start_time = std::chrono::high_resolution_clock::now();
#endif
            utils::commonNeighbor(P, G[v], NP, 0, ps, 0, gvs);
            utils::commonNeighbor(X, G[v], NX, 0, xs, 0, gvs);
            // std::cout<<"NP size:"<<NP.size()<<std::endl;
            // std::cout<<"NX size:"<<NX.size()<<std::endl;
#ifdef TIMECOUNT
            mergetime += std::chrono::high_resolution_clock::now() - merge_start_time;
#endif
            BKP(NP, NX, result);
            P.erase(P.begin() + vit1);
            X.insert(X.begin() + utils::binarySearch(v, X, 0, xs), v);
            ps--;
            xs++;
        }
        else if (P[vit1] == G[u][vit2])
        {
            vit1++;
            vit2++;
        }
        else
            vit2++;
    }
}
int Graph::get_num_nodes() const
{
    return N;
}
void Graph::get_neighbors(node u, vector<node> &neis) const
{
    if (!neis.empty())
        neis.clear();
    neis.insert(neis.begin(), G[u].begin(), G[u].end());
}
double Graph::MC(const vec &nodes, const int *Vrank)
{
    tqdm bar;
    unsigned long result = 0;
    auto start_time = chrono::high_resolution_clock::now();
    int count = 0;
    // bool* processed = calloc(N,sizeof(bool));
    for (const int &n : nodes)
    {
        bar.progress2(count++, nodes.size());
        int i = Vrank[n];
        // std::cout<<"Vrank of 0"<<Vrank[0]<<std::endl;
        int gns = degrees[n];
        std::cout << "Degree of 0" << degrees[0] << std::endl;
        vec P;
        P.reserve(gns);
        vec X;
        X.reserve(gns);
        for (const int &adj : G[n])
        {

            if (Vrank[adj] > i && P.size() < PSIZEUB)
                P.push_back(adj);
            else
                X.push_back(adj);
        }
        std::cout << "P size" << P.size() << std::endl;
        std::cout << "X size" << X.size() << std::endl;
        BKP(P, X, result);
        break;
    }
    auto end_time = chrono::high_resolution_clock::now();
    cout << endl
         << "Total MC:" << result << endl;
    chrono::duration<double> diff = end_time - start_time;
    return diff.count();
}

#ifndef GRAPH_H
#define GRAPH_H
#include "utils.h"
using namespace std;
using namespace chrono;

typedef long node;
typedef long weight;
typedef unsigned long long ull;
struct SIB_Tree_Node {
	int base;
	int next_ptr;
	ull val;
};
class Graph {
public:
    Graph (const int VN) : N(VN), G(new vec[VN]), degrees(new int[VN]) {}
    Graph(vec* OG, const int VN) : N(VN), G(OG), degrees(new int[VN]) {
        for (int i=0; i!=N; i++)
            degrees[i] = G[i].size();
    }
    void get_neighbors(node u, vector<node>& neis) const;
    int get_num_nodes() const;
    virtual ~Graph() {
        delete[] degrees;
    }
    virtual void commonNeighbor(const int i, const int j, unsigned long& cn);
    virtual void commonNeighborCP(const int i, const int j, unsigned long& cn);
    virtual void commonNeighborNB(const int i, const int j, unsigned long& cn);
    virtual void commonNeighborNB_simd(const int i, const int j, unsigned long& cn);
    virtual void reportRatio(ostream&);
    virtual void commonNeighborBS(const int i, const int j, unsigned long& cn);

    virtual double calCN(const pvec& nodePairs, const bool NB);
    virtual double calCNBS(const pvec& nodePairs);
    virtual unsigned long calCNCP(const pvec& nodePairs);

    virtual void calCN(const vec& nodes);
    virtual double calF(const pvec& nodePairs, const bool NB);
    virtual double calR(const pvec& nodePairs);
    virtual double calTri_simd(bool reportNumber=false);
    virtual double calTri(bool reportNumber=false);
    virtual void calF();
    virtual void calTriF();

    virtual double MC(const vec& nodes, const int* Vrank);
    
// protected:
    const int N;
    vec* G;
    int* degrees;
    int selectPivot(const vec& P, const vec& X);
    virtual void BKP(vec& P, vec& X, unsigned long& result);
};

#endif